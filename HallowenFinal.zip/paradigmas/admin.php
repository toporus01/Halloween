<?php
session_start();

// Verificar si el usuario es el administrador (se asume que el admin tiene usuario_id = 1)
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_id'] != 1) {
    die("Acceso denegado.");
}

// Crear la carpeta 'uploads' si no existe
if (!is_dir('uploads')) {
    mkdir('uploads', 0777, true);
}

// Procesar el formulario de agregar disfraz
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db.php';
    $conn = conectarBD();

    // Validar y sanitizar los datos del formulario
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);
    $imagen = $_FILES['imagen']['name'];
    $imagen_tmp = $_FILES['imagen']['tmp_name'];
    $imagen_destino = 'uploads/' . basename($imagen);

    // Mover el archivo de imagen subido a la carpeta 'uploads'
    if (move_uploaded_file($imagen_tmp, $imagen_destino)) {
        // Insertar el nuevo disfraz en la base de datos
        $sql = "INSERT INTO disfraces (nombre, descripcion, imagen, votos) VALUES ('$nombre', '$descripcion', '$imagen_destino', 0)";
        if ($conn->query($sql) === TRUE) {
            echo "Nuevo disfraz agregado exitosamente.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error al subir la imagen.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administración de Disfraces</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Agregar Nuevo Disfraz</h1>
    <form method="post" action="admin.php" enctype="multipart/form-data">
        <label for="nombre">Nombre del Disfraz:</label>
        <input type="text" id="nombre" name="nombre" required>
        <br>
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion" required></textarea>
        <br>
        <label for="imagen">Imagen del Disfraz:</label>
        <input type="file" id="imagen" name="imagen" accept="image/*" required>
        <br>
        <button type="submit">Agregar Disfraz</button>
    </form>
</body>
</html>
