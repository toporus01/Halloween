<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    die("Necesitas iniciar sesión para votar.");
}

include 'db.php';
$conn = conectarBD();

$disfraz_id = $conn->real_escape_string($_POST['disfraz_id']);
$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT * FROM votos WHERE usuario_id = $usuario_id AND disfraz_id = $disfraz_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    die("Ya has votado por este disfraz.");
} else {
    $sql = "INSERT INTO votos (usuario_id, disfraz_id) VALUES ($usuario_id, $disfraz_id)";
    $conn->query($sql);

    $sql = "UPDATE disfraces SET votos = votos + 1 WHERE id = $disfraz_id";
    $conn->query($sql);

    echo "Gracias por tu voto.";
}

$conn->close();
?>
