<?php
include 'db.php';
$conn = conectarBD();

$sql = "SELECT id, nombre, descripcion, votos, imagen FROM disfraces";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Disfraces</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Lista de Disfraces</h1>
    <ul>
    <?php while ($row = $result->fetch_assoc()): ?>
        <li>
            <h2><?php echo htmlspecialchars($row['nombre']); ?></h2>
            <p><?php echo htmlspecialchars($row['descripcion']); ?></p>
            <p>Votos: <?php echo $row['votos']; ?></p>
            <?php if (!empty($row['imagen'])): ?>
                <img src="<?php echo htmlspecialchars($row['imagen']); ?>" alt="Imagen del Disfraz" width="200">
            <?php endif; ?>
            <form method="post" action="votar.php">
                <input type="hidden" name="disfraz_id" value="<?php echo $row['id']; ?>">
                <button type="submit">Votar</button>
            </form>
        </li>
    <?php endwhile; ?>
    </ul>
</body>
</html>

<?php
$conn->close();
?>
