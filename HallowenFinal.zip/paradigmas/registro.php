<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db.php';
    $conn = conectarBD();

    $usuario = $conn->real_escape_string($_POST['usuario']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO usuarios (usuario, password) VALUES ('$usuario', '$password')";
    if ($conn->query($sql) === TRUE) {
        echo "Registro exitoso. Puedes <a href='login.php'>iniciar sesión</a>.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Creepster&display=swap" rel="stylesheet">
</head>
<body>
    <h1>Registro de Usuario</h1>
    <form method="post" action="registro.php">
        <label for="usuario">Usuario:</label>
        <input type="text" id="usuario" name="usuario" required>
        <br>
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <button type="submit">Registrar</button>
    </form>
</body>
</html>
