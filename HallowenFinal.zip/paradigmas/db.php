<?php
function conectarBD() {
    $conn = new mysqli('127.0.0.1', 'root', '', 'Halloween');
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }
    return $conn;
}
?>
